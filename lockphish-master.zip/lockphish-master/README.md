# Lockphish v2.0

Lockphish it's the first tool (07/04/2020) for phishing attacks on the lock screen, designed to grab Windows credentials, Android PIN and iPhone Passcode using a https link.
## LockPhish Tutorial: https://www.kalilinux.in/2020/05/lockphish.html
## Author: https://github.com/kali-linux-tutorial/lockphish
## Twitter: https://twitter.com/kalilinux_in



### Features:

#### Lockscreen phishing page for Windows, Android and iPhone
#### Auto detect device
#### Port Forwarding by Ngrok
#### IP Tracker

## Legal disclaimer:

Usage of Lockphish for attacking targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program. 

### Usage:
```
https://github.com/kali-linux-tutorial/lockphish
cd lockphish
bash lockphish.sh
```


